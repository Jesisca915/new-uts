import 'package:daftarproduk/screens/halamanUtama.dart';
import 'package:daftarproduk/services/produk_service.dart';
import 'package:flutter/material.dart';

class ShoppingListScreen extends StatefulWidget {
  const ShoppingListScreen({super.key});

  @override
  State<ShoppingListScreen> createState() => _ShoppingListScreenState();
}

class _ShoppingListScreenState extends State<ShoppingListScreen> {
  final TextEditingController _controller1 = TextEditingController();
  final TextEditingController _controller2 = TextEditingController();
  final ShoppingService _shoppingService = ShoppingService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Daftar Produk"),
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(10),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller1,
                    decoration:
                    const InputDecoration(hintText: 'Masukkan Kode Barang'),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.all(10),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller2,
                    decoration:
                    const InputDecoration(hintText: 'Masukkan Nama Barang'),
                  ),
                ),
              ],
            ),
          ),
          // FloatingActionButton(
          //   child: Icon(Icons.add),
          //   onPressed: () {
          //     _shoppingService.addShoppingItem(
          //         _controller1.text, _controller2.text);
          //     Navigator.push(context,
          //         MaterialPageRoute(builder: (context) => OutputHalaman()));
          //   },
          // ),
          TextButton(
            onPressed: () {
              _shoppingService.addShoppingItem(_controller1.text, _controller2.text);
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ShoppingListScreen()));
            },

            child: Text("Simpan"),
          )
        ],
      ),
    );
  }
}
